_G.math.randomseed(_G.os.time());
