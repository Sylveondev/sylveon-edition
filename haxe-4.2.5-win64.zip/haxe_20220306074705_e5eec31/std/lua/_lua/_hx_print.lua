_hx_print = print or (function() end)
