_hx_apply_self = function(self, f, ...)
  return self[f](self,...)
end
